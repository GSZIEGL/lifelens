
import io, re, zipfile, hashlib, shutil, tempfile
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image, ImageStat, ExifTags, ImageOps

try:
    import cv2
except Exception:
    cv2 = None

APP_TITLE = "LifeLens AI Private V4"
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff"}
VIDEO_EXT = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".3gp", ".m4v"}
SUPPORTED_EXT = IMAGE_EXT | VIDEO_EXT

st.set_page_config(page_title=APP_TITLE, page_icon="🔒", layout="wide")

st.markdown("""
<style>
.privacy-box{padding:1rem;border-radius:16px;background:#ecfdf5;border:1px solid #10b981;color:#064e3b;margin-bottom:1rem}
.warn-box{padding:1rem;border-radius:16px;background:#fff7ed;border:1px solid #f97316;color:#7c2d12;margin-bottom:1rem}
</style>
""", unsafe_allow_html=True)

def get_download_file_bytes(filename: str):
    for p in [Path(__file__).resolve().parent / filename, Path.cwd() / filename]:
        if p.exists():
            return p.read_bytes()
    return None

def safe_name(text: str) -> str:
    text = str(text or "").strip().replace("ő","o").replace("ű","u").replace("Ő","O").replace("Ű","U")
    text = re.sub(r"[^\w\- .áéíóöúüÁÉÍÓÖÚÜ]+", "_", text)
    text = re.sub(r"\s+", "_", text)
    return text[:120] if text else "ismeretlen"

def md5_file(path: Path, chunk_size=1024*1024):
    h = hashlib.md5()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b: break
            h.update(b)
    return h.hexdigest()

def average_hash(img, hash_size=8):
    try:
        g = ImageOps.grayscale(img).resize((hash_size, hash_size))
        arr = np.asarray(g, dtype=np.float32)
        avg = arr.mean()
        return "".join("1" if b else "0" for b in (arr > avg).flatten())
    except Exception:
        return ""

def get_exif_datetime(img):
    try:
        exif = img.getexif()
        tag_map = {ExifTags.TAGS.get(k, k): v for k, v in exif.items()}
        for key in ["DateTimeOriginal", "DateTimeDigitized", "DateTime"]:
            if key in tag_map:
                try:
                    return datetime.strptime(str(tag_map[key]), "%Y:%m:%d %H:%M:%S")
                except Exception:
                    pass
    except Exception:
        pass
    return None

def fallback_datetime(path):
    try:
        return datetime.fromtimestamp(path.stat().st_mtime)
    except Exception:
        return None

def classify_tags(path, dt, media_type, w=None, h=None):
    tags = ["videó" if media_type == "video" else "kép"]
    name = path.name.lower()
    if "screenshot" in name or "képernyőkép" in name or "kepernyokep" in name:
        tags.append("screenshot")
    if dt:
        if dt.month == 12: tags += ["december", "karácsony/időszak"]
        if dt.month in [6,7,8]: tags.append("nyár")
        if dt.month in [1,2]: tags.append("tél")
    for kw in ["balaton","nyaralas","nyaralás","karacsony","karácsony","szulinap","szülinap","foci","football","traktor","auto","autó","kutya","macska","ovi","bölcsi","bolcsi"]:
        if kw in name: tags.append(kw)
    return sorted(set(tags))

def quality_score(img):
    try:
        g = np.asarray(ImageOps.grayscale(img).resize((256,256)), dtype=np.float32)
        sharp = np.diff(g, axis=1).var() + np.diff(g, axis=0).var()
        small = ImageOps.grayscale(img).resize((128,128))
        stat = ImageStat.Stat(small)
        mean, std = stat.mean[0], stat.stddev[0]
        exposure = max(0, 1 - abs(mean-128)/128)*60 + min(std/64, 1)*40
        return round(float(sharp*0.7 + exposure*0.3), 2)
    except Exception:
        return 0.0

def extract_zip(uploaded_file, dest):
    with zipfile.ZipFile(uploaded_file) as z:
        z.extractall(dest)

def iter_media(root):
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXT:
            yield p

def get_video_metadata(path, preview_dir):
    empty = {"duration_sec": None, "fps": None, "frame_count": None, "width": None, "height": None, "preview_path": "", "quality_score": 0, "phash": ""}
    if cv2 is None: return empty
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened(): return empty
    fps = cap.get(cv2.CAP_PROP_FPS) or 0
    frames = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    dur = frames / fps if fps else None
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(frames*0.35) if frames else 0)
    ok, frame = cap.read()
    cap.release()
    preview_path, q, phash = "", 0, ""
    if ok and frame is not None:
        img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        q, phash = quality_score(img), average_hash(img)
        preview_dir.mkdir(parents=True, exist_ok=True)
        pp = preview_dir / (hashlib.md5(str(path).encode()).hexdigest()+".jpg")
        img.save(pp, quality=85)
        preview_path = str(pp)
    return {"duration_sec": round(dur,1) if dur else None, "fps": round(fps,1) if fps else None, "frame_count": int(frames) if frames else None, "width": w, "height": h, "preview_path": preview_path, "quality_score": q, "phash": phash}

def scan_media(root, limit=None):
    rows, files = [], list(iter_media(root))
    if limit: files = files[:limit]
    preview_dir = Path(st.session_state.work_dir) / "video_previews"
    prog = st.progress(0, text="Média indexelése...")
    for i,p in enumerate(files):
        mt = "video" if p.suffix.lower() in VIDEO_EXT else "image"
        try:
            dt = fallback_datetime(p)
            if mt == "image":
                with Image.open(p) as img:
                    img = ImageOps.exif_transpose(img)
                    dt = get_exif_datetime(img) or dt
                    w,h = img.size
                    q = quality_score(img)
                    phash = average_hash(img)
                    tags = classify_tags(p, dt, mt, w, h)
                    preview = str(p)
                    dur = fps = None
            else:
                meta = get_video_metadata(p, preview_dir)
                w,h,dur,fps,preview,q,phash = meta["width"], meta["height"], meta["duration_sec"], meta["fps"], meta["preview_path"], meta["quality_score"], meta["phash"]
                tags = classify_tags(p, dt, mt, w, h)
            rows.append({"media_type": mt, "path": str(p), "filename": p.name, "folder": str(p.parent), "size_mb": round(p.stat().st_size/(1024*1024),2), "md5": md5_file(p), "phash": phash, "date": dt, "year": dt.year if dt else None, "month": dt.month if dt else None, "width": w, "height": h, "duration_sec": dur, "fps": fps, "preview_path": preview, "quality_score": q, "tags": ", ".join(tags), "is_screenshot": "screenshot" in tags})
        except Exception as e:
            rows.append({"media_type": mt, "path": str(p), "filename": p.name, "folder": str(p.parent), "error": str(e)})
        prog.progress((i+1)/max(len(files),1), text=f"Indexelés: {i+1}/{len(files)}")
    prog.empty()
    df = pd.DataFrame(rows)
    if not df.empty and "date" in df.columns:
        df = df.sort_values("date", ascending=True, na_position="last")
    return df

def duplicate_summary(df):
    if df.empty or "md5" not in df.columns: return pd.DataFrame()
    dup = df[df.duplicated("md5", keep=False)].copy()
    if dup.empty: return dup
    dup["duplicate_group"] = dup.groupby("md5").ngroup()+1
    return dup.sort_values(["duplicate_group","filename"])

def build_album(df, mode, n):
    work = df.copy()
    if mode == "Top fotók": work = work[work.media_type.eq("image")]
    elif mode == "Top videók": work = work[work.media_type.eq("video")]
    elif mode == "Karácsony": work = work[work.tags.fillna("").str.contains("karácsony|karacsony|december", case=False, regex=True)]
    elif mode == "Nyár / nyaralás": work = work[work.tags.fillna("").str.contains("nyár|nyar|balaton|nyaralas|nyaralás", case=False, regex=True)]
    return work.sort_values("quality_score", ascending=False).head(n)

def folder_for_row(row, structure):
    y, m = int(row.get("year",0) or 0), int(row.get("month",0) or 0)
    tags, mt = str(row.get("tags","")).lower(), row.get("media_type","image")
    media_folder = "Videók" if mt == "video" else "Képek"
    if structure == "Év / hónap":
        return (Path(str(y)) / f"{m:02d}" / media_folder) if y and m else Path("Dátum_nélkül")/media_folder
    if structure == "Téma szerint":
        if "karácsony" in tags or "karacsony" in tags or "december" in tags: return Path("Ünnepek")/"Karácsony"/media_folder
        if "nyár" in tags or "nyar" in tags or "balaton" in tags: return Path("Nyaralás")/media_folder
        if "screenshot" in tags: return Path("Screenshotok")
        if "traktor" in tags or "auto" in tags or "autó" in tags: return Path("Járművek")/media_folder
        if "foci" in tags or "football" in tags: return Path("Sport")/media_folder
        return Path("Egyéb")/media_folder
    return (Path(str(y)) if y else Path("Dátum_nélkül")) / folder_for_row(row, "Téma szerint")

def create_zip(df, structure, include_mode, top_n):
    work = df.copy()
    if include_mode == "Csak top média": work = work.sort_values("quality_score", ascending=False).head(top_n)
    elif include_mode == "Duplikátumok nélkül": work = work.drop_duplicates("md5", keep="first")
    elif include_mode == "Screenshotok nélkül": work = work[~work.get("is_screenshot", False).fillna(False)]
    elif include_mode == "Csak képek": work = work[work.media_type.eq("image")]
    elif include_mode == "Csak videók": work = work[work.media_type.eq("video")]
    mem, used = io.BytesIO(), set()
    with zipfile.ZipFile(mem, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for _,r in work.iterrows():
            src = Path(r["path"])
            if not src.exists(): continue
            arc = str(folder_for_row(r, structure) / safe_name(r.get("filename", src.name)))
            if arc in used:
                stem, suf = Path(arc).stem, Path(arc).suffix
                arc = str(Path(arc).parent / f"{stem}_{hashlib.md5(str(src).encode()).hexdigest()[:6]}{suf}")
            used.add(arc); z.write(src, arc)
        z.writestr("LifeLens_index.csv", work.drop(columns=["md5","phash"], errors="ignore").to_csv(index=False).encode("utf-8-sig"))
    return mem.getvalue()

def create_html_album(df, title, n):
    work = df.sort_values("quality_score", ascending=False).head(n)
    cards = []
    for _,r in work.iterrows():
        prev = str(r.get("preview_path") or r.get("path"))
        img = f'<img src="{prev}" style="width:100%;border-radius:12px;max-height:180px;object-fit:cover;">' if prev and Path(prev).exists() else ""
        cards.append(f"<div class='card'>{img}<p><b>{r.get('media_type')}</b> · {r.get('filename')}</p><p>{r.get('date')}</p><p>{r.get('tags')}</p><small>{r.get('path')}</small></div>")
    return f"""<!doctype html><html><head><meta charset='utf-8'><title>{title}</title><style>body{{font-family:Arial;background:#f8fafc;margin:40px}}.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}}.card{{background:white;border:1px solid #e2e8f0;border-radius:16px;padding:16px}}</style></head><body><h1>{title}</h1><div class='grid'>{''.join(cards)}</div></body></html>""".encode("utf-8")

st.title("🔒 LifeLens AI Private V4")
st.caption("Privát fotó- és videórendező, helyi futtatási segítséggel")

st.markdown("""<div class="privacy-box"><b>🔒 Privát működés:</b> családi képekhez a helyi/desktop verziót ajánljuk. Helyi futtatásnál a képek és videók a saját gépeden maradnak, nem kerülnek feltöltésre külső szerverre.</div>""", unsafe_allow_html=True)

st.markdown("## 🚀 Két használati mód")
c1,c2 = st.columns(2)
with c1:
    st.markdown("### 🌐 Online teszt\nKisebb, nem érzékeny tesztanyaghoz ZIP-pel. Privát családi képekhez nem ajánlott.")
with c2:
    st.markdown("### 💻 Helyi privát verzió\nSaját gépen fut, látja a C:, D:, külső HDD és NAS mappákat. Ez az ajánlott.")

desktop_pkg = get_download_file_bytes("LifeLens_Private_V4_Desktop_Package.zip")
if desktop_pkg:
    st.download_button("⬇ LifeLens Desktop / helyi indítócsomag letöltése", desktop_pkg, "LifeLens_Private_V4_Desktop_Package.zip", "application/zip", use_container_width=True)
else:
    st.warning("A helyi indítócsomag nincs az app mappájában. A külön V4 csomagból töltsd le.")
st.link_button("🐍 Python letöltése, ha a helyi indító kéri", "https://www.python.org/downloads/")
st.divider()

if "work_dir" not in st.session_state:
    st.session_state.work_dir = tempfile.mkdtemp(prefix="lifelens_")

st.sidebar.header("1. Forrás kiválasztása")
source_mode = st.sidebar.radio("Honnan jöjjenek a képek/videók?", ["ZIP feltöltés", "Helyi mappa útvonala"])
work_root = None
base_tmp = Path(st.session_state.work_dir)

if source_mode == "ZIP feltöltés":
    uploaded = st.sidebar.file_uploader("Képek és videók ZIP fájlban", type=["zip"])
    if uploaded and st.sidebar.button("ZIP kibontása és beolvasása", use_container_width=True):
        extract_dir = base_tmp / "uploaded_zip"
        if extract_dir.exists(): shutil.rmtree(extract_dir)
        extract_dir.mkdir(parents=True, exist_ok=True)
        extract_zip(uploaded, extract_dir)
        st.session_state["photo_root"] = str(extract_dir)
        st.success("ZIP kibontva.")
else:
    folder_text = st.sidebar.text_input("Helyi mappa útvonala", value="")
    st.sidebar.caption("Online appban a C:\\ útvonal nem működik. Helyi futtatásnál igen.")
    if st.sidebar.button("Mappa beállítása", use_container_width=True):
        p = Path(folder_text)
        if p.exists() and p.is_dir():
            st.session_state["photo_root"] = str(p)
            st.success("Mappa beállítva.")
        else:
            st.error("Ez a mappa nem található ezen a környezeten.")

if st.session_state.get("photo_root"):
    work_root = Path(st.session_state["photo_root"])

st.sidebar.header("2. Elemzés")
limit_scan = st.sidebar.number_input("Max. médiafájl teszthez", 100, 100000, 3000, 100)
if st.sidebar.button("Indexelés indítása", use_container_width=True, disabled=work_root is None):
    st.session_state["photo_index"] = scan_media(work_root, int(limit_scan))
    st.success("Indexelés kész.")

df = st.session_state.get("photo_index", pd.DataFrame())

tab0, tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs(["💻 Helyi privát futtatás","📊 Áttekintés","🔎 Keresés","🎞️ Videók","🧹 Nagytakarítás","🎯 Albumok","📦 Rendezett ZIP","🧭 Jövő"])

with tab0:
    st.subheader("💻 Helyi privát futtatás")
    st.info("Online Streamlit Cloudon a helyi C:\\ vagy D:\\ útvonal nem működik, mert a felhős szerver nem látja a saját géped meghajtóit.")
    pkg = get_download_file_bytes("LifeLens_Private_V4_Desktop_Package.zip")
    if pkg:
        st.download_button("⬇ LifeLens helyi indítócsomag letöltése", pkg, "LifeLens_Private_V4_Desktop_Package.zip", "application/zip", use_container_width=True)
    st.link_button("Python letöltése – hivatalos oldal", "https://www.python.org/downloads/")
    st.code("1. ZIP kicsomagolása pl. C:\\LifeLens\n2. Dupla katt: START_LIFELENS_LOCAL.bat\n3. Megnyílik: http://localhost:8501\n4. Helyi mappa: C:\\Users\\T470\\Desktop\\Foto_App", language="text")

if work_root is None or df.empty:
    st.info("Válassz forrást és indítsd el az indexelést. Privát képekhez használd a 💻 Helyi privát futtatás fület.")
    st.stop()

with tab1:
    st.subheader("Áttekintés")
    c1,c2,c3,c4,c5 = st.columns(5)
    c1.metric("Összes média", len(df))
    c2.metric("Képek", int(df.media_type.eq("image").sum()))
    c3.metric("Videók", int(df.media_type.eq("video").sum()))
    c4.metric("Évek", df.year.nunique())
    c5.metric("Méret", f"{df.size_mb.sum():.1f} MB")
    pivot = df.groupby(["year","media_type"]).size().reset_index(name="Darab").pivot(index="year", columns="media_type", values="Darab").fillna(0)
    st.bar_chart(pivot)
    st.dataframe(df[["media_type","filename","date","year","month","size_mb","duration_sec","quality_score","tags","folder"]].head(300), use_container_width=True)

with tab2:
    st.subheader("Keresés")
    q = st.text_input("Mit keresel?", placeholder="Balaton, karácsony, traktor, 2024, videó...")
    res = df.copy()
    if q:
        ql = q.lower()
        res = res[res.filename.fillna("").str.lower().str.contains(ql, regex=False) | res.folder.fillna("").str.lower().str.contains(ql, regex=False) | res.tags.fillna("").str.lower().str.contains(ql, regex=False) | res.media_type.fillna("").str.lower().str.contains(ql, regex=False) | res.year.fillna("").astype(str).str.contains(ql, regex=False)]
    st.write(f"Találatok: **{len(res)}**")
    st.dataframe(res[["media_type","filename","date","duration_sec","quality_score","tags","path"]].head(500), use_container_width=True)
    cols = st.columns(4)
    for i,(_,r) in enumerate(res.head(12).iterrows()):
        p = Path(str(r.get("preview_path") or r.get("path")))
        if p.exists():
            with cols[i%4]: st.image(str(p), caption=f"{r.media_type} · {r.filename}", use_container_width=True)

with tab3:
    st.subheader("Videók")
    vids = df[df.media_type.eq("video")]
    if vids.empty: st.info("Nem találtam videót.")
    else:
        c1,c2,c3 = st.columns(3)
        c1.metric("Videók", len(vids))
        c2.metric("Összes hossz", f"{vids.duration_sec.fillna(0).sum()/60:.1f} perc")
        c3.metric("Méret", f"{vids.size_mb.sum():.1f} MB")
        st.dataframe(vids[["filename","date","duration_sec","width","height","fps","quality_score","tags","path"]].head(500), use_container_width=True)

with tab4:
    st.subheader("Nagytakarítás")
    dup = duplicate_summary(df)
    c1,c2,c3 = st.columns(3)
    c1.metric("Pontos duplikátum sorok", len(dup))
    c2.metric("Duplikátumok mérete", f"{dup.size_mb.sum() if not dup.empty else 0:.1f} MB")
    c3.metric("Screenshotok", int(df.is_screenshot.fillna(False).sum()))
    if dup.empty: st.success("Nem találtam pontos MD5 duplikátumot.")
    else: st.dataframe(dup[["duplicate_group","media_type","filename","size_mb","path"]].head(1000), use_container_width=True)
    st.markdown("### Gyenge minőség gyanús média")
    st.dataframe(df.sort_values("quality_score").head(100)[["media_type","filename","quality_score","size_mb","path"]], use_container_width=True)

with tab5:
    st.subheader("Albumok")
    mode = st.selectbox("Album típusa", ["Top képek és videók","Top fotók","Top videók","Karácsony","Nyár / nyaralás"])
    n = st.slider("Médiafájlok száma", 10, 500, 80, 10)
    album = build_album(df, mode, n)
    st.dataframe(album[["media_type","filename","date","duration_sec","quality_score","tags","path"]].head(500), use_container_width=True)
    html = create_html_album(album, f"LifeLens album – {mode}", n)
    st.download_button("HTML album index letöltése", html, f"LifeLens_album_{safe_name(mode)}.html", "text/html", use_container_width=True)

with tab6:
    st.subheader("Rendezett ZIP export")
    structure = st.selectbox("Mappastruktúra", ["Év / hónap","Téma szerint","Év / téma"])
    include_mode = st.selectbox("Mit tegyen bele?", ["Minden média","Duplikátumok nélkül","Screenshotok nélkül","Csak top média","Csak képek","Csak videók"])
    top_n = st.slider("Top média száma", 50, 2000, 500, 50)
    if st.button("Rendezett ZIP elkészítése", use_container_width=True):
        st.session_state["organized_zip"] = create_zip(df, structure, include_mode, top_n)
        st.success("ZIP elkészült.")
    if st.session_state.get("organized_zip"):
        st.download_button("Rendezett ZIP letöltése", st.session_state["organized_zip"], f"LifeLens_Rendezett_{safe_name(structure)}.zip", "application/zip", use_container_width=True)

with tab7:
    st.subheader("Jövőbeli források")
    st.markdown("- Google Drive OAuth\n- OneDrive OAuth\n- Google Photos később\n- Natív Windows app\n- Fotókönyv PDF\n- Arcfelismerés opcionálisan, csak helyben")
