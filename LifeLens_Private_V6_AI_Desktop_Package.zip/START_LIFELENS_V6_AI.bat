@echo off
chcp 65001 >nul
cd /d "%~dp0"
title LifeLens AI Private V6 - AI helyi indito
echo.
echo =====================================================
echo   LifeLens AI Private V6 - HELYI PRIVAT FUTTATAS
echo =====================================================
echo.
echo Ha localhost:8501 latszik, minden a sajat gepeden fut.
echo.

set PY_CMD=

py -3 --version >nul 2>nul
if not errorlevel 1 (
    set PY_CMD=py -3
    goto python_ok
)

python --version >nul 2>nul
if not errorlevel 1 (
    set PY_CMD=python
    goto python_ok
)

echo [HIBA] Nem talalok mukodo Python telepitest.
echo Toltsd le: https://www.python.org/downloads/
echo Telepiteskor pipald be: Add Python to PATH
pause
exit /b 1

:python_ok
echo Python rendben: %PY_CMD%

if not exist "lifelens_private_app_v6_ai.py" (
    echo [HIBA] Nem talalom: lifelens_private_app_v6_ai.py
    dir
    pause
    exit /b 1
)

if not exist "requirements_lifelens_private_v6_ai.txt" (
    echo [HIBA] Nem talalom: requirements_lifelens_private_v6_ai.txt
    dir
    pause
    exit /b 1
)

echo [1/3] Alap csomagok telepitese...
%PY_CMD% -m pip install -r requirements_lifelens_private_v6_ai.txt

echo.
echo Szeretned telepiteni az opcionális AI képelemzést is? 
echo Ez nagyobb letoltes lehet, de csak igy tudja tenylegesen "megnezni" a kepeket.
choice /C IN /M "I = igen, N = nem"
if errorlevel 2 goto skip_ai
if errorlevel 1 goto install_ai

:install_ai
echo [2/3] AI csomagok telepitese: torch transformers...
%PY_CMD% -m pip install torch transformers
goto run_app

:skip_ai
echo AI csomagok kihagyva. Az app szabalyalapu modban is fut.

:run_app
echo.
echo [3/3] LifeLens inditasa...
echo Nyisd meg, ha nem nyilik automatikusan: http://localhost:8501
%PY_CMD% -m streamlit run lifelens_private_app_v6_ai.py --server.address localhost --server.port 8501
pause
