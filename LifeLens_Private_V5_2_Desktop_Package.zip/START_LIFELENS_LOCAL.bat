@echo off
chcp 65001 >nul
cd /d "%~dp0"
title LifeLens AI Private V5.2 - helyi futtatas
echo.
echo ===============================================
echo   LifeLens AI Private V5.2 - helyi futtatas
echo ===============================================
echo.
echo Ez az app a SAJAT GEPEDEN fut.
echo A kepeid es videoid nem kerulnek feltoltesre kulso szerverre.
echo.
echo Aktualis mappa:
echo %cd%
echo.

set PY_CMD=

py -3 --version >nul 2>nul
if not errorlevel 1 (
    set PY_CMD=py -3
    goto python_ok
)

python --version >nul 2>nul
if not errorlevel 1 (
    set PY_CMD=python
    goto python_ok
)

:python_missing
echo [HIBA] Nem talalok mukodo Python telepitest.
echo.
echo Toltsd le innen:
echo https://www.python.org/downloads/
echo.
echo Telepiteskor pipald be:
echo Add Python to PATH
echo.
pause
exit /b 1

:python_ok
echo Python rendben: %PY_CMD%
echo.

if not exist "requirements_lifelens_private_v5.txt" (
    echo [HIBA] Nem talalom ezt a fajlt:
    echo requirements_lifelens_private_v5.txt
    echo.
    echo Fontos: a START_LIFELENS_LOCAL.bat fajlt a kicsomagolt LifeLens mappabol inditsd.
    echo Ne huzd at masik mappaba kulon.
    echo.
    echo A mappaban ezek vannak:
    dir
    echo.
    pause
    exit /b 1
)

if not exist "lifelens_private_app_v5.py" (
    echo [HIBA] Nem talalom ezt a fajlt:
    echo lifelens_private_app_v5.py
    echo.
    echo A START_LIFELENS_LOCAL.bat fajlt ugyanabban a mappaban kell tartani, mint az app fajlt.
    pause
    exit /b 1
)

echo [1/2] Csomagok telepitese/frissitese...
%PY_CMD% -m pip install -r requirements_lifelens_private_v5.txt

if errorlevel 1 (
    echo.
    echo [HIBA] A csomagok telepitese nem sikerult.
    echo.
    echo Tipp:
    echo - ellenorizd az internetkapcsolatot
    echo - probald ujra
    echo - ha ceges gep, lehet hogy pip/letoltes tiltva van
    echo.
    pause
    exit /b 1
)

echo.
echo [2/2] LifeLens inditasa helyben...
echo Ha nem nyilik meg automatikusan, ezt nyisd meg:
echo http://localhost:8501
echo.
%PY_CMD% -m streamlit run lifelens_private_app_v5.py --server.address localhost --server.port 8501

pause
