@echo off
title LifeLens AI Private V5 - helyi futtatas
echo.
echo ===============================================
echo   LifeLens AI Private V5 - helyi futtatas
echo ===============================================
echo.
echo Ez az app a SAJAT GEPEDEN fut.
echo A kepeid es videoid nem kerulnek feltoltesre kulso szerverre.
echo.
where python >nul 2>nul
if errorlevel 1 (
    echo [HIBA] A Python nem talalhato.
    echo.
    echo Toltsd le innen:
    echo https://www.python.org/downloads/
    echo.
    echo Telepiteskor pipald be: Add Python to PATH
    echo.
    pause
    exit /b 1
)
echo Python rendben.
echo Csomagok telepitese/frissitese...
python -m pip install --upgrade pip
python -m pip install -r requirements_lifelens_private_v5.txt
echo LifeLens inditasa helyben...
python -m streamlit run lifelens_private_app_v5.py --server.address localhost --server.port 8501
pause
