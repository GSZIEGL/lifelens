Demo Family Alpha V2 – synthetic demo pack for LifeLens V8.1
